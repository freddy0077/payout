import React from "react";
import LinkItem from "./LinkItem";
import ProgressBar from "./LinkItem";

const Links = () => {
  return (
    <div>
      <ProgressBar />
    </div>
  );
};

export default Links;
