export interface Links {
  id: string;
  name: string;
  image?: string;
  linkUrl: string;
}
